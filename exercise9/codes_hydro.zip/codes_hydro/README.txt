
We provide python code fragments that need to be integrated into a larger program. This version also includes the general advection code that was requested in exercise 8. 

bc --> periodic boundaries
hll  --> HLL solver routine
hydro_iso_classic  --> classic hydro solver for isothermal EOS (no integration of energy needed)
hydro_adi_classic  --> classic hydro solver for non-isothermal EOS
hydro_iso_riemann  --> Riemann solver for isothermal EOS (no integration of energy needed)
hydro_adi_riemann  --> Riemann solver for non-isothermal EOS

